import { z } from 'zod'

export const personalInfoSchema = z.object({
  phone: z
    .string()
    .min(1, 'Phone is required')
    .regex(/^\d+$/, 'Phone must contain digits only')
    .startsWith('0', 'Phone must start with 0')
    .length(10, 'Phone must contain exactly 10 digits'),
  firstName: z
    .string()
    .trim()
    .min(1, 'First name is required')
    .max(50, 'First name must be at most 50 characters'),
  lastName: z
    .string()
    .trim()
    .min(1, 'Last name is required')
    .max(50, 'Last name must be at most 50 characters'),
  gender: z.enum(['male', 'female'], {
    message: 'Gender is required',
  }),
})

export type PersonalInfoFormValues = z.infer<typeof personalInfoSchema>
